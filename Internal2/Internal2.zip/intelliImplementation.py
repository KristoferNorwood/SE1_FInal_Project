#!/usr/bin/python
import testIntellegentModel
from typing import List

def diagnose(data):
	return testIntellegentModel.diagnose(data)
	
