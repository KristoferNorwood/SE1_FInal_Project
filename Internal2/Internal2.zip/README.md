# SE1_Final_Project
Final Project for Software Engineering 1 at UCO, Fall 2020

To install the requirements for this project, run `pip install -r requirements.txt`

app.py is the file that runs the GUI