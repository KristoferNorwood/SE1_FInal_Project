#!/usr/bin/python
from abc import ABC, abstractmethod
from typing import List
import intelliImplementation

	
def diagnose(data):
	diagnosis = intelliImplementation.diagnose(data)
	return diagnosis
	
