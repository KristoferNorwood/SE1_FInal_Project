#!/usr/bin/python
# -*- coding: UTF-8 -*-
from Internal import socket
from Internal import clientThread
from Internal import pinkRay
from Internal import threading
from Internal import exceptions
from Internal import logging
from typing import List

class pinkServer(object):
	def startServer(self) -> None:
		pass

	def processData(self, aThread : ClientThread, aInStream : socket, aAddress : socket) -> None:
		pass

	def __init__(self):
		self.___s : socket = None
		self.___serverAddress : tuple = None
		self.___newThread : clientThread = None
		self.___inbound_stream : socket = None
		self.___address : socket = None
		self._unnamed_pinkRay_ : pinkRay = None
		self._unnamed_threading_ : threading = None
		self._unnamed_exceptions_ : exceptions = None
		self._unnamed_logging_ : logging = None
		self._unnamed_clientThread_ : clientThread = None

