#!/usr/bin/python
# -*- coding: UTF-8 -*-
from Internal import socket
from Internal import intelligentModel
from Internal import clientThread
from typing import List

class processClientData(object):
	# def getFriendDiagnosis(self, aData : str) -> int:
	# 	pass

	# def getVerdict(self, aDiagArray : list) -> long:
	# 	pass

	def sendDiagReq(self) -> None:
		root = et.fromstring(data) 
		i = 0
		j = 0
		diagnosis = []
		myRoot = et.tostring(root)
		diagnosis.insert(3, 29)
		for i in range(12):
			s = socket.socket()
			s.settimeout(30)
			s.connect((friendServers[i][j],friendServers[i][j+1]))
			while True:
				s.send(bytes(myRoot))
				incomingVote = s.recv(65536)
				friendData = incomingVote.decode("utf8")
				diagnosis.insert(i, getFriendDiagnosis(friendData))
				s.close()
				break
		pass

	def diagnose(self) -> None:
		#change to intelligentModel.diagnose or whatever
		myDiag = intelligentDiagnosisModel(data)
		diagnosis.insert(12, myDiag)
		verdict = getVerdict(diagnosis)
		if verdict:
			myDiag = 2
		else:
			myDiag = 4
		for patient in root:
			patient.find('class').text = str(myDiag)
		myRoot = et.tostring(root)
		inStream.send(bytes(myRoot))
		inStream.close()
		pass

	def __init__(self):
		self._unnamed_socket_ : socket = None
		self._unnamed_intelligentModel_ : intelligentModel = None
		self._unnamed_clientThread_ : clientThread = None

	def getVerdict(self, diagArray):
		vote = 0
		vote1 = 0
		for num in diagArray:
			if num == 2:
				vote += 1
			else:
				vote1 += 1
		if vote1 > vote:
			return True
		else:
			return False
    

	def getFriendDiagnosis(self, data):
		diagnosis = ""
		root = et.fromstring(data) 
		for patient in root:
			diagnosis = patient.find('class').text
		diag = int(diagnosis)
		return diag