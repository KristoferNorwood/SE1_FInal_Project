#!/usr/bin/python
# -*- coding: UTF-8 -*-
from Internal import socket
from Internal import processClientData
from Internal import pinkServer
from Internal import exceptions
from Internal import processServerData
from Internal import threading
from typing import List

class clientThread(threading.Thread):

#put processClientData.diagnose(data, inStream)
	def clientData(self, aData : str, aInStream : socket) -> None:
		pass


#put processServerData.diagnose(data, inStream)
	def serverData(self, aData : str, aInStream : socket) -> None:
		pass

# init
	def clientThread(self, aThread : ClientThread, aInStream : socket) -> None:
		pass

	def getData(self) -> str:
		return self.___data

	# def __init__(self):
	# 	self.___data : str = None
	# 	self.___csocket : socket = None
	# 	self.___inStream : socket = None
	# 	self.___chunk : bytes = None
	# 	self._unnamed_processClientData_ : processClientData = None
	# 	self._unnamed_pinkServer_ : pinkServer = None
	# 	self._unnamed_exceptions_ : exceptions = None
	# 	self._unnamed_processServerData_ : processServerData = None
	# 	self._unnamed_socket_ : socket = None

def __init__(self, inStream, address):
        threading.Thread.__init__(self)
        self.csocket = address
        self.inStream = inStream
        print("New connection added: ", inStream)

def run(self):
	# start of get data function
        print("connection from : ", self.csocket)
        data = ""
        flag = False
        while True:
            
            chunk = self.inStream.recv(65536)
            data += chunk.decode("utf8")
            if "myapp".encode('utf-8') in chunk:
                flag = True
                data = ""
                self.inStream.send(bytes(1))
                chunk = self.inStream.recv(65536)
                data += chunk.decode("utf-8")
	# end of get data function
            if not data:
                print('Bye')
                break
            if "/Dataset".encode('utf-8') in chunk:
                break
        if flag == True:
            processClientData(data, self.inStream)
        else: 
            processServerData(data, self.inStream)
        print("Client d/c'ed")
        return