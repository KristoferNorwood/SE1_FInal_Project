#!/usr/bin/python
# -*- coding: UTF-8 -*-
from Internal import IntelliImplementation
from typing import List

class futureIntellegentModel(IntelliImplementation):
	def diagnose(self, aData : str) -> int:
		pass

