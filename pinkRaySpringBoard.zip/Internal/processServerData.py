#!/usr/bin/python
# -*- coding: UTF-8 -*-
from Internal import clientThread
from Internal import exceptions
from Internal import socket
from Internal import intelligentModel
from typing import List
from lxml import etree as et
myRoot = et.tostring(data)
class processServerData(object):
	root
	myRoot
	def diagnose(self) -> None:
		#replace with intelligentModel.diagnose or 
		#whatever the class above the intelliImplementor is
		diagnosis = intelligentDiagnosisModel(data)
		pass

	def parseFrom(self, aData : str):
		self.root = et.fromstring(data)
		pass

	def parseToString(self, aRoot) -> str:
		for patient in root:
			patient.find('class').text = str(diagnosis)
		self.myRoot = et.tostring(root)
		#maybe break up into send data and add logger here
		self.inStream.send(bytes(myRoot))
    	self.inStream.close()
	# pass

	def __init__(self):
		self._unnamed_clientThread_ : clientThread = None
		self._unnamed_exceptions_ : exceptions = None
		self._unnamed_socket_ : socket = None
		self._unnamed_intelligentModel_ : intelligentModel = None

