#!/usr/bin/python
# -*- coding: UTF-8 -*-
from Internal import guiApplication
from Internal import pinkServer
from Internal import logging
from typing import List

class pinkRay(object):
	# def startSystem(self) -> None:
		pass

	# def __init__(self):
		self.___gui : guiApplication = None
		self.___server : pinkServer = None
		self.___pinkLogger : logging = None
		self._unnamed_logging_ : logging = None
		self._unnamed_guiApplication_ : guiApplication = None
		self._unnamed_pinkServer_ : pinkServer = None

